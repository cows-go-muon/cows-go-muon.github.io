function doYourThing() {
  var canvas = document.getElementById("Canvas");
  var ctx = canvas.getContext("2d");

  function setupCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  setupCanvas();
  window.onresize = function() {
    setupCanvas();
  };

  function theBigDouble(number) {
    return number * 2;
  }
  console.log(canvas.width);
  console.log(canvas.height);

  function drawww(x, y) {
    ctx.beginPath();
    ctx.lineTo(x - 100, y);
    ctx.lineTo(x, 200 + y);
    ctx.lineTo(x + 100, y);
    ctx.lineTo(x + 200, 200 + y);
    ctx.lineTo(x + 300, y);
    ctx.stroke();
  }
  var c = 0;
  var d = 0;
  function receiveInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
  }
  var rndmNmbr = receiveInteger(-500, 500);
  var rndmNmbr2 = receiveInteger(-500, 500);
  function colorize() {
    var gradient2 = ctx.createLinearGradient(rndmNmbr, rndmNmbr2, c, d);
    gradient2.addColorStop(0, "#ED6059");
    // gradient2.addColorStop(0.15, '#1E90FF');
    gradient2.addColorStop(0.2, "#E7CC35");
    gradient2.addColorStop(0.4, "#ADFF2F");
    gradient2.addColorStop(0.6, "#3CB371");
    gradient2.addColorStop(0.84, "#111DB6 ");
    // gradient2.addColorStop(.6, '#00BFFF');
    // gradient2.addColorStop(0.675, '#1E90FF');
    // gradient2.addColorStop(0.75, '#ADFF2F');
    // gradient2.addColorStop(0.85, '#3CB371');
    // gradient2.addColorStop(0.98, '#191970');
    gradient2.addColorStop(1, "#9932CC");
    ctx.lineWidth = 4;
    ctx.strokeStyle = gradient2;
  }
  colorize();

  function cycle() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // ctx.strokeStyle=gradient2
    ctx.fillStyle = "Black";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    if (c > canvas.width || d > canvas.height) {
      c = 0;
      d = 0;
      rndmNmbr = receiveInteger(-500, 500);
      rndmNmbr2 = receiveInteger(-500, 500);
    } else {
      c += canvas.width / 150;
      d += canvas.height / 150;
    }
    ctx.fillStyle = "Black";
    ctx.fillRect(canvas.width - 40, 0, canvas.width, 40);

    colorize();
    for (let i = -1; i < 30; ++i) {
      for (let j = 0; j < 20; j++) {
        drawww(50 * i, -50 + 50 * j);
        drawww(-50 + 50 * j, 50 * i);
      }
    }
    // console.log(c)
    ctx.fillStyle = "Black";
    ctx.fillRect(canvas.width - 80, 0, canvas.width, 60);
    ctx.fillStyle = "White";
    ctx.fillText("X=" + c, canvas.width - 70, 20);
    ctx.fillText("Y=" + d, canvas.width - 70, 40);
    requestAnimationFrame(cycle);
  }
  requestAnimationFrame(cycle);
}
doYourThing();

function doTheOtherThing() {
  var canvas = document.getElementById("Canvas2");
  var ctx = canvas.getContext("2d");

  function setupCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    ctx.globalCompositeOperation = "xor";
  }
  setupCanvas();
  window.onresize = function() {
    setupCanvas();
  };
  //Will not show up on the screen
  function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
  }
  function r(e) {
    return getRandomInt(e) + 2;
  }
  var speedSum;
  let array = [];
  for (let i = 0; i < 250; i++) {
    array.push({
      position: {
        x: getRandomInt(canvas.width),
        y: getRandomInt(canvas.height)
      },
      phase: 2 * Math.PI * Math.random() / 10,
      radius: r(10),
      velocity: {
        horiz: 2.5 * (Math.random() - 0.5),
        vert: 2.5 * (Math.random() - 0.5)
      }
    });
  }

  function rndmClr() {
    return "#" + Math.floor(Math.random() * 16777215).toString(16);
  }
  function randomGenerateCircle(x, y, size) {
    ctx.fillStyle = rndmClr();
    ctx.beginPath();
    ctx.arc(x, y, size + 2, 0, 2 * Math.PI);
    ctx.fill();
  }
  function bouncyBoi(number) {
    if (array[number].position.x + array[number].radius > canvas.width) {
      array[number].velocity.horiz = -Math.abs(array[number].velocity.horiz);
    } else if (array[number].position.x - array[number].radius < 0) {
      array[number].velocity.horiz = Math.abs(array[number].velocity.horiz);
    } else if (
      array[number].position.y + array[number].radius >
      canvas.height
    ) {
      array[number].velocity.vert = -Math.abs(array[number].velocity.vert);
    } else if (array[number].position.y - array[number].radius < 0) {
      array[number].velocity.vert = Math.abs(array[number].velocity.vert);
    }
  }
  // var i;
  // for (i=0; i<500; i++) {
  // rndmGnrtCrcl((getRandomInt(canvas.width)),(getRandomInt(canvas.height)),(getRandomInt(18)));
  // }
  let h = 1;

  // function flashyBoi() {
  function flashyBoi() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    h++;
    speedSum = 0;

    for (let i = 0; i < array.length; i++) {
      speedSum += array[i].velocity.horiz + array[i].velocity.vert;
      bouncyBoi(i);
      array[i].position.x += 1.15 * array[i].velocity.horiz;
      array[i].position.y += 1.15 * array[i].velocity.vert;
      var ball1 = array[i];
      array[i].radius = Math.abs(10 * Math.sin(h / 100 + i));
      for (let j = 0; j < array.length; j++) {
        var ball2 = array[j];
        if (!(i === j)) {
          bouncyBoi(j);
          if (
            array[i].position.x + array[i].radius + array[j].radius >
              array[j].position.x &&
            array[i].position.x <
              array[j].position.x + array[i].radius + array[j].radius &&
            array[i].position.y + array[i].radius + array[j].radius >
              array[j].position.y &&
            array[i].position.y <
              array[j].position.y + array[i].radius + array[j].radius
          ) {
            var dx = ball2.position.x - ball1.position.x;
            var dy = ball2.position.y - ball1.position.y;
            var distance = Math.sqrt(dx * dx + dy * dy);
            var minDistance = ball1.radius + ball2.radius;

            if (distance < minDistance) {
              var angle = Math.atan2(dy, dx);
              var tx = ball1.position.x + dx / distance * minDistance;
              var ty = ball1.position.y + dy / distance * minDistance;
              var ax = tx - ball2.position.x;
              var ay = ty - ball2.position.y;

              ball1.position.x -= ax;
              ball1.position.y -= ay;
              ball2.position.x += ax;
              ball2.position.y += ay;

              ball1.velocity.horiz -= 1.05*ax;
              ball1.velocity.vert -= 1.05*ay;
              ball2.velocity.horiz += 1.05*ax;
              ball2.velocity.vert += 1.05*ay;
            }
          }
        }
      }
      randomGenerateCircle(
        array[i].position.x,
        array[i].position.y,
        array[i].radius
      );
    }
    // }
    console.log(speedSum);

    requestAnimationFrame(flashyBoi);
  }
  requestAnimationFrame(flashyBoi);
}
doTheOtherThing();
// Needed for test:
// functions, variables, parameters, conditional statements

//___________________get mouse input___________________

// let mouse = {
//   down: false,
//   x: 0,
//   y: 0
// };
// canvas.addEventListener("mousemove", event => {
//   mouse.x = event.clientX;
//   mouse.y = event.clientY;
// });
// canvas.addEventListener("mousedown", event => {
//   mouse.down = true;
//   // console.log(mouse);
// });
// canvas.addEventListener("mouseup", event => {
//   mouse.down = false;
// });

//___________________get keyboard input___________________

// const keys = [];
// document.onkeydown = function(e){
//   keys[e.keyCode] = true;
//   //console.log(e.keyCode);
// }
// document.onkeyup = function(e){
//   keys[e.keyCode] = false;
// }

//___________________animation loop ___________________

// function cycle(){
//   ctx.clearRect(0, 0, canvas.width, canvas.height);

//   requestAnimationFrame(cycle);
// }
// requestAnimationFrame(cycle);

//Will not show up on the screen